<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Generate_barcode
{
    function generate($i)
	{
        $a=$i;    
        return $a;
    }
}

?>