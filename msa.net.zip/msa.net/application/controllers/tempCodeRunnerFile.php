<?php
' '.$b->nama_barang
					."</li>";