<!-- Error Container -->
<div id="error-container">
    <div class="error-options">
        <h3>&nbsp;</h3>
    </div>
    <div class="row">
        <div class="col-sm-8 col-sm-offset-2 text-center">
            <h1 class="animation-pulse"><i class="gi gi-settings text-warning"></i></h1>
            <h2 class="h3 themed-color-fire">Opps, we are sorry but this module is under construction<br>But do not worry, we are on it..</h2>
        </div>
    </div>
</div>
<!-- END Error Container -->